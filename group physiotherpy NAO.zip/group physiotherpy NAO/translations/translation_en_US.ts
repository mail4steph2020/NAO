<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Choice</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="vanished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="vanished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="vanished">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="vanished">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="vanished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="vanished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="vanished">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="vanished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="vanished"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="vanished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="vanished">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="vanished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="vanished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice (1)</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="vanished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="vanished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="vanished">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="vanished">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="vanished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="vanished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="vanished">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="vanished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="vanished"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="vanished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="vanished">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="vanished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="vanished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice (1)/Choice</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="obsolete">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="obsolete">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="obsolete">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="obsolete">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="obsolete">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="obsolete">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="obsolete">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="obsolete">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="obsolete"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="obsolete">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="obsolete">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="obsolete">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="obsolete">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice (1)/Choice (1)</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="vanished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="vanished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="vanished">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="vanished">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="vanished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="vanished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="vanished">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="vanished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="vanished"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="vanished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="vanished">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="vanished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="vanished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice (1)/Choice (1)/Choice</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="obsolete">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="obsolete">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="obsolete">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="obsolete">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="obsolete">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="obsolete">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="obsolete">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="obsolete">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="obsolete"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="obsolete">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="obsolete">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="obsolete">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="obsolete">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice (1)/Choice (1)/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Thank you, your feedback is appreciated.</source>
            <comment>Text</comment>
            <translation type="obsolete">Thank you, your feedback is appreciated.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>No problem. I can help with your neck</source>
            <comment>Text</comment>
            <translation type="obsolete">No problem. I can help with your neck</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice/Choice</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="obsolete">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="obsolete">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="obsolete">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="obsolete">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="obsolete">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="obsolete">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="obsolete">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="obsolete">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="obsolete"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="obsolete">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="obsolete">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="obsolete">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="obsolete">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>No problem. I can help with your neck</source>
            <comment>Text</comment>
            <translation type="obsolete">No problem. I can help with your neck</translation>
        </message>
        <message>
            <source>slowly put your head back as far as you feel comfortable and then forwards. plese repeat 3 times</source>
            <comment>Text</comment>
            <translation type="obsolete">slowly put your head back as far as you feel comfortable and then forwards. plese repeat 3 times</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
        <message>
            <source>HNo problem. I can help with your shoulder</source>
            <comment>Text</comment>
            <translation type="obsolete">HNo problem. I can help with your shoulder</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Choice/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
        <message>
            <source>eNo problem. I can help with your elbow</source>
            <comment>Text</comment>
            <translation type="obsolete">eNo problem. I can help with your elbow</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello I am your Physiotherapist for today</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello I am your Physiotherapist for today</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>I can  not find any face here</source>
            <comment>Text</comment>
            <translation type="obsolete">I can  not find any face here</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>That was a great session, good work.</source>
            <comment>Text</comment>
            <translation type="unfinished">That was a great session, good work.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Before we work out exercies i need to determine your age. Please touch my right foot, if you are over 50 years of age. otherwies touch the left foot.</source>
            <comment>Text</comment>
            <translation type="unfinished">Before we work out exercies i need to determine your age. Please touch my right foot, if you are over 50 years of age. otherwies touch the left foot.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>[13:27] Moore, Dan
As you're over 50 please take care during your treatment so you dont injur youself.</source>
            <comment>Text</comment>
            <translation type="obsolete">[13:27] Moore, Dan
As you're over 50 please take care during your treatment so you dont injur youself.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>As you're over 50 please take care during your treatment so you dont injur youself.</source>
            <comment>Text</comment>
            <translation type="unfinished">As you're over 50 please take care during your treatment so you dont injur youself.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Before we finish, would you like to return and pick another exercise. Touch my right foot for yes and my left foot for no.</source>
            <comment>Text</comment>
            <translation type="obsolete">Before we finish, would you like to return and pick another exercise. Touch my right foot for yes and my left foot for no.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Before we finish, would you like to return and pick another exercise. Touch the front of my head for yes and the behind of my head for no.</source>
            <comment>Text</comment>
            <translation type="unfinished">Before we finish, would you like to return and pick another exercise. Touch the front of my head for yes and the behind of my head for no.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Great, we can now return to the beginning of the exercise section</source>
            <comment>Text</comment>
            <translation type="unfinished">Great, we can now return to the beginning of the exercise section</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (6)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Please continue with these exrcises frequently, if problems continue please return again for another visit. Have a wonderful day.</source>
            <comment>Text</comment>
            <translation type="unfinished">Please continue with these exrcises frequently, if problems continue please return again for another visit. Have a wonderful day.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/feedback or do exe again /Choice</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="unfinished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="unfinished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="unfinished">help/help me/i don't know</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="unfinished">exit/stop/quit</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="unfinished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="unfinished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="unfinished">, / or </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="unfinished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="unfinished"> you can ask me: %s. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="unfinished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="unfinished">I did not understand. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="unfinished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="unfinished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/feedback or do exe again /feedback model/Choice</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="unfinished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="unfinished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="unfinished">help/help me/i don't know</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="unfinished">exit/stop/quit</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="unfinished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="unfinished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="unfinished">, / or </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="unfinished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="unfinished"> you can ask me: %s. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="unfinished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="unfinished">I did not understand. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="unfinished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="unfinished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/feedback or do exe again /feedback model/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Thank you, your feedback is appreciated.</source>
            <comment>Text</comment>
            <translation type="unfinished">Thank you, your feedback is appreciated.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/physiotherapist exercies/Animated Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No problem. I can help with your neck</source>
            <comment>Text</comment>
            <translation type="unfinished">No problem. I can help with your neck</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/physiotherapist exercies/Choice</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="unfinished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="unfinished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="unfinished">help/help me/i don't know</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="unfinished">exit/stop/quit</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="unfinished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="unfinished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="unfinished">, / or </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="unfinished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="unfinished"> you can ask me: %s. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="unfinished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="unfinished">I did not understand. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="unfinished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="unfinished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
</TS>
